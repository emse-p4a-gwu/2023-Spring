# Name:  Last, First
# netID: Insert your netID here

# I worked with the following classmates on this assignment:
# 1) Name: Last, First
# 2) Name: Last, First

######################################################################
# Place your solutions below here
######################################################################

# Note: For each of the functions in this assignment, you will need to write a
# test function AND the function itself. I strongly recommend you
# write the test function *FIRST*, and then write the function.
# Your test functions will count for half of the available credit for each
# problem. Think carefully about the test cases to include in your test
# functions.




#--------------------------------------------------------------
# ignore_rest
# This comment is for the autograder - it will ignore all code below here
